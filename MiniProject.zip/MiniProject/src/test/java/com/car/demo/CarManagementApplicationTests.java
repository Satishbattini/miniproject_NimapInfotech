package com.car.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
